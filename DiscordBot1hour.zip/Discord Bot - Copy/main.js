const Discord = require('discord.js')

const client = new Discord.Client();

const PREFIX = '-';

client.once('ready' , () => {
    console.log ('I am online');
});

client.on('message', message =>{
    if(!message.content.startsWith(PREFIX) || message.author.bot) return;

    const args = message.content.slice(PREFIX.length).split(/ +/);
    const command = args .shift().toLowerCase();

    if(command === 'ping'){
        message.channel.send('pong!');
    }  else if (command === 'hypixelstatus'){
         message.channel.send('https://status.hypixel.net/')
    }
});


client.login('ODM3MzU5Njg3NDIxOTE5MjUy.YIrZ-g.nHT_C9NUCPc7efjOpcT31X2Cjq4');